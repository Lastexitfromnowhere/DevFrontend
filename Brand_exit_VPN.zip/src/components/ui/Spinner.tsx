// src/components/ui/Spinner.tsx
export function Spinner({ className = "" }: { className?: string }) {
    return (
      <div 
        className={`animate-spin rounded-full h-4 w-4 border-2 border-green-500 border-t-transparent ${className}`} 
      />
    );
  }
  
  // src/lib/utils.ts
  import { clsx, type ClassValue } from 'clsx';
  import { twMerge } from 'tailwind-merge';
  
  export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
  }