import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Globe, Cpu, Wifi, Activity, Upload } from 'lucide-react';
import type { NetworkStats as NetworkStatsType } from '@/types/ecosystem.types';

export default function NetworkStats() {
  const [stats, setStats] = useState<NetworkStatsType | null>(null);

  useEffect(() => {
    // Fonction pour récupérer les données de l'API
    async function fetchNetworkStats() {
      try {
        const response = await fetch('https://vpn-9ki1.onrender.com/api/network-stats'); // Utiliser l'URL de votre API Render
        const data: NetworkStatsType = await response.json();
        setStats(data);
      } catch (error) {
        console.error('Erreur lors de la récupération des statistiques du réseau:', error);
      }
    }

    fetchNetworkStats();
  }, []);

  // Couleurs associées à l'état de santé du réseau
  const healthColors = {
    healthy: 'text-green-400',
    warning: 'text-yellow-400',
    critical: 'text-red-400'
  };

  if (!stats) {
    return <div>Chargement des statistiques réseau...</div>;
  }

  return (
    <Card className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Globe className="text-green-400" size={24} />
          <h3 className="text-xl font-bold text-green-300">Network Statistics</h3>
        </div>
        <div className={`flex items-center space-x-1 ${healthColors[stats.networkHealth]}`}>
          <Activity size={16} />
          <span className="text-sm capitalize">{stats.networkHealth}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="text-center p-4 bg-black/20 rounded">
          <Cpu className="mx-auto mb-2 text-green-400" size={20} />
          <p className="text-sm text-green-500">Total Nodes</p>
          <p className="text-xl font-bold text-green-300">{stats.totalNodes}</p>
        </div>
        <div className="text-center p-4 bg-black/20 rounded">
          <Wifi className="mx-auto mb-2 text-green-400" size={20} />
          <p className="text-sm text-green-500">Active Nodes</p>
          <p className="text-xl font-bold text-green-300">{stats.activeNodes}</p>
        </div>
        <div className="text-center p-4 bg-black/20 rounded">
          <Upload className="mx-auto mb-2 text-green-400" size={20} />
          <p className="text-sm text-green-500">Total Bandwidth</p>
          <p className="text-xl font-bold text-green-300">{stats.totalBandwidth} TB</p>
        </div>
        <div className="text-center p-4 bg-black/20 rounded">
          <Activity className="mx-auto mb-2 text-green-400" size={20} />
          <p className="text-sm text-green-500">Avg. Uptime</p>
          <p className="text-xl font-bold text-green-300">{stats.averageUptime}%</p>
        </div>
      </div>

      <div className="text-center text-xs text-green-500">
        {`// Network data updates every 5 minutes`}
      </div>
    </Card>
  );
}