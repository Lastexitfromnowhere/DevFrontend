'use client';

import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/Card';
import { TerminalButton } from '@/components/ui/terminal';
import { Activity, Upload, Users, Server, Network } from 'lucide-react';
import { useWalletContext } from '@/contexts/WalletContext';
import type { NodeStatus as NodeStatusType } from '@/types/ecosystem.types';
import axios from 'axios';

export default function NodeStatus() {
  const { isConnected, account } = useWalletContext();
  const [status, setStatus] = useState<NodeStatusType>({
    active: false,
    bandwidth: 0,
    earnings: 0,
    connectedUsers: 0,
    lastUpdated: new Date().toISOString(),
    nodeIp: null
  });
  const [isLoading, setIsLoading] = useState(false);

  // Fonction pour démarrer le nœud
  const startNode = async () => {
    if (!account) {
      console.error('Wallet not connected');
      return;
    }

    setIsLoading(true);
    try {
      const response = await axios.post('https://vpn-9ki1.onrender.com/api/connect', {
        walletAddress: account,
        nodeInfo: 'Client Node',
        isHost: false
      });

      if (response.data.success) {
        setStatus(prev => ({
          ...prev,
          active: true,
          nodeIp: response.data.ip || 'N/A',
          bandwidth: response.data.bandwidth || 0,
          lastUpdated: new Date().toISOString()
        }));
      }
    } catch (error) {
      console.error('Failed to start node:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Fonction pour arrêter le nœud
  const stopNode = async () => {
    if (!account) {
      console.error('Wallet not connected');
      return;
    }

    setIsLoading(true);
    try {
      const response = await axios.post('https://vpn-9ki1.onrender.com/api/disconnect');

      if (response.data.success) {
        setStatus(prev => ({
          ...prev,
          active: false,
          bandwidth: 0,
          connectedUsers: 0,
          nodeIp: null,
          lastUpdated: new Date().toISOString()
        }));
      }
    } catch (error) {
      console.error('Failed to stop node:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Fonction pour récupérer le statut du nœud périodiquement
  const fetchNodeStatus = async () => {
    if (!status.active) return;

    try {
      const response = await axios.get('https://vpn-9ki1.onrender.com/api/status');
      
      if (response.data.success) {
        setStatus(prev => ({
          ...prev,
          bandwidth: response.data.bandwidth || prev.bandwidth,
          nodeIp: response.data.ip || prev.nodeIp,
          active: response.data.isRunning,
          lastUpdated: new Date().toISOString()
        }));
      }
    } catch (error) {
      console.error('Failed to fetch node status:', error);
    }
  };

  // Effet pour récupérer périodiquement le statut du nœud
  useEffect(() => {
    if (status.active) {
      const interval = setInterval(fetchNodeStatus, 30000); // Toutes les 30 secondes
      return () => clearInterval(interval);
    }
  }, [status.active]);

  if (!isConnected) {
    return (
      <Card className="text-center p-6">
        <Server className="mx-auto mb-4 text-green-400" size={48} />
        <p className="text-green-300">Connect your wallet to start operating a node</p>
      </Card>
    );
  }

  return (
    <Card className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Server className="text-green-400" size={24} />
          <h3 className="text-xl font-bold text-green-300">Node Status</h3>
        </div>
        <TerminalButton
          onClick={status.active ? stopNode : startNode}
          variant={status.active ? 'danger' : 'primary'}
          icon={status.active ? <Activity size={16} /> : <Server size={16} />}
          disabled={isLoading}
        >
          {isLoading 
            ? '$ processing...' 
            : (status.active ? '$ stop_node' : '$ start_node')
          }
        </TerminalButton>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="text-center p-4 bg-black/20 rounded">
          <Upload className="mx-auto mb-2 text-green-400" size={20} />
          <p className="text-sm text-green-500">Bandwidth</p>
          <p className="text-xl font-bold text-green-300">{status.bandwidth.toFixed(2)} MB</p>
        </div>
        <div className="text-center p-4 bg-black/20 rounded">
          <Activity className="mx-auto mb-2 text-green-400" size={20} />
          <p className="text-sm text-green-500">Earnings</p>
          <p className="text-xl font-bold text-green-300">{status.earnings.toFixed(2)} RWRD</p>
        </div>
        <div className="text-center p-4 bg-black/20 rounded">
          <Users className="mx-auto mb-2 text-green-400" size={20} />
          <p className="text-sm text-green-500">Connected</p>
          <p className="text-xl font-bold text-green-300">{status.connectedUsers}</p>
        </div>
      </div>

      <div className="flex justify-between text-xs text-green-500">
        <div className="flex items-center space-x-2">
          <Network className="w-4 h-4" />
          <span>Node IP: {status.nodeIp || 'Not available'}</span>
        </div>
        <span>Last Update: {new Date(status.lastUpdated).toLocaleTimeString()}</span>
      </div>
    </Card>
  );
}