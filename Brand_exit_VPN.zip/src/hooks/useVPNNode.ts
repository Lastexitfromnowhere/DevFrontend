// src/hooks/useVPNNode.ts
import { useState, useCallback, useEffect } from 'react';
import type { NodeStatus } from '@/types/ecosystem.types';

export const useVPNNode = () => {
  const [nodeStatus, setNodeStatus] = useState<NodeStatus>({
    active: false,
    bandwidth: 0,
    earnings: 0,
    connectedUsers: 0,
    lastUpdated: new Date().toISOString()
  });

  const startNode = useCallback(() => {
    setNodeStatus(prev => ({
      ...prev,
      active: true
    }));
  }, []);

  const stopNode = useCallback(() => {
    setNodeStatus(prev => ({
      ...prev,
      active: false
    }));
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (nodeStatus.active) {
      interval = setInterval(() => {
        setNodeStatus(prev => ({
          ...prev,
          bandwidth: prev.bandwidth + Math.random() * 0.1,
          earnings: prev.earnings + Math.random() * 0.01,
          connectedUsers: Math.floor(Math.random() * 5),
          lastUpdated: new Date().toISOString()
        }));
      }, 5000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [nodeStatus.active]);

  return {
    nodeStatus,
    startNode,
    stopNode
  };
};
