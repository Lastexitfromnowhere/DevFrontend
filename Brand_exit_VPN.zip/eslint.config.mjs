/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['lucide-react'],
  reactStrictMode: true,
  poweredByHeader: false,
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production',
  },
  async rewrites() {
    return process.env.NODE_ENV === 'production' 
      ? [] 
      : [
          {
            source: '/api/connect',
            destination: 'http://localhost:3001/connect'
          },
          {
            source: '/api/rewards/:userId',
            destination: 'http://localhost:3001/rewards/:userId'
          },
          {
            source: '/api/status',
            destination: 'http://localhost:3001/status'
          }
        ];
  },
};

export default nextConfig;